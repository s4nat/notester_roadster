window.onload=function()
{
   
}

function onClickTest()
{
    console.log("hello world");
    testFunction();
}
async function testFunction()
{
    const value = await firebase.database().ref("/test").child("/Test").once('value');
    firebase.database().ref("/test").child("/Test").set(value.val()+1);
}

function generatePlayer(_name , _xCood,_yCood)
{
    if (_xCood==null || _yCood==null)
    {
         _xCood = 0;
         _yCood = 0;
    }
    console.log(_name);
    var player=
    {
        name:_name,
        id :generateID(12),
        xCood :  _xCood,//TODO: set precision level based of the game prescision 
        yCood :  _yCood,//TODO: set precision level based of the game prescision 
    }
    return player; 
}1

async function HostCreateRoom() 
{
    //required Parameters
    //HostplayeroBject will contain the object for player details 
    _roomID = generateID(6);
    _name = document.getElementById("username");
    if (_name.value === ""){
        return 
    }
    _xCood = 0;
    _yCood = 0;
    hostPlayerObject=generatePlayer(_name.value , _xCood,_yCood);
    var roomParam = 
    {
        dateTime : Date.now(),
        roomID : _roomID,
        hostID: hostPlayerObject.id,
        players : {hostPlayerObject},
        playerCount: 0,
        game:
        {
            ball:
            {
                ballx :300,
                bally :570,
                dX : 0,
                dY :-5,
            },
            map:"<>"
        }
    }
    
    var response = await firebase.database().ref("/roomOpened/").push(roomParam);
    var val= await firebase.database().ref('/roomOpened').orderByChild('roomID').equalTo(_roomID).once('value');
    
   
    await firebase.database().ref("/roomOpened/"+val.node_.children_.root_.key+"/players").on('child_added',async (data)=>
    {
        roomKey = val.node_.children_.root_.key
        console.log("before:"+roomKey);
        countPlayer(roomKey);
    });
}

async function HostCreateRoomTest()
{
    //required Parameters
    //GET required parameters 
    _roomID =document.getElementById("txtboxUsername");
    testHost = generatePlayer(_name="TEST")
    var roomParam = 
    {
        dateTime : Date.now(),
        roomID : generateID(6),
        hostID: testHost.id,
        players : {testHost},
        game:
        {
            ball:
            {
                ballx :400,
                bally :570,
                dX :3,
                dY :-3,
            },
            map:"<>"
        }
    }
    firebase.database().ref("/roomOpened/").push(roomParam);
}
function joinRoomAdaptor()
{
    _roomId = document.getElementById("roomId");
    _name = document.getElementById("username");
    player = generatePlayer(_name.value,0,0);
    joinRoom(_roomID,player);
}
async function joinRoom(_roomID,_playerConfig)
{
    //Querrying for room ID
    var val= await firebase.database().ref('/roomOpened').orderByChild('roomID').equalTo(_roomID).once('value');
    if(val.val()!= null)
    {
        /// event when cache hit
        obj = (val.val());
        objKey = val.node_.children_.root_.key
        
        //push new user into the the game user directory
        firebase.database().ref("/roomOpened/"+objKey+"/players").push(_playerConfig);
    }
    else
    {
        // event when cache miss
        console.error("Invalid Room Id")
    }
}

async function leaveRoom(_roomID,_playerConfig) //TODO:implement local player state in main game logic and track get roomID info
{
    //Querrying for room ID
    var val= await firebase.database().ref('/roomOpened').orderByChild('roomID').equalTo(_roomID).once('value');
    obj = (val.val());
    objKey = val.node_.children_.root_.key
    var userDetail = await firebase.database().ref('/roomOpened/'+objKey+"/players").orderByChild('id').equalTo(_playerConfig.id).once('value');
    if(val.val()!= null )
    {
        
        //console.log(objKey);
        // event when cache hit
        userDetail = userDetail.node_.children_.root_.key
        //push new user into the the game user directory
        firebase.database().ref("/roomOpened/"+objKey+"/players/"+userDetail).remove();
        console.log(val.node_.children_.root_.key);
        countPlayer(val.node_.children_.root_.key);
    }
    else
    {
        // event when cache miss
        console.error("Invalid Room Id")
    }
   
}

/// generates room ID
function generateID(length)
 {
    var text = "";
    var possible = "abcdefghijklmnopqrstuvwxyz0123456789";
  
    for (var i = 0; i < length; i++)
    {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }    
    return text;
}
//counts player in a giver room 
async function countPlayer(_roomID)
{
    count =0 ;
    console.log(_roomID);
    firebase.database().ref('/roomOpened/'+_roomID+"/players").once('value').then(function(snapshot)
    {
        snapshot.forEach(function(childSnapshot) 
        {
            count++;
        });
        console.log(count);
        firebase.database().ref("/roomOpened/"+_roomID+"/playerCount").set(count);
    })
    
    console.log("updated count value")
}