var canvas = document.getElementById("gameCanvas");
var ctx = canvas.getContext("2d");
var ballR = 10, x = canvas.width/2, y = canvas.height-30,
    dx = 0, dy = -5, pongH = 20, pongW = 140,
    rightKey = false, leftKey = false, upKey = false; downKey = false; brickRows = 3, brickCol = 9,
    brickW = 50, brickH = 30, brickPadding = 9, brickOffsetTop = 200,
    brickOffsetLeft = 30;

var bricks = [];

function Pong(side, isPlayer){
    this.isPlayer = isPlayer;
    this.pos = canvas.width / 2;
    this.side = side;
    if (side == "Top") {
        this.y = 0;
        this.pos -= pongW / 2;
        this.x = this.pos;
    }
    else if (side == "Right"){
        this.pos -= pongW/2;
        this.y = this.pos;
        this.x = canvas.width - pongH;
    }
    else if (side == "Left"){
        this.pos -= pongW/2;
        this.y = this.pos;
        this.x = 0;
    }
    else if (side == "Bottom"){
        this.y = canvas.width - pongH;
        this.pos -= pongW/2;
        this.x = this.pos;
    }
}

Pong.prototype.drawPong = function(){
    if (!this.isPlayer){
        if(this.side == "Right" || this.side == "Left"){
            this.pos = y - pongW/2 + 40*(2*Math.random()-1);
        }
        else{
            this.pos = x - pongW/2 + 40*(2*Math.random()-1);
        }
    }
    ctx.beginPath();
    if (this.side == "Top" || this.side=="Bottom"){
        this.x = this.pos;
        ctx.rect(this.pos, this.y, pongW, pongH);
    }
    else if (this.side == "Right" || this.side == "Left"){
        this.y = this.pos;
        ctx.rect(this.x, this.pos, pongH, pongW);
    }
    ctx.fillStyle = !this.isPlayer ? "#011AFE" : "#1EFE69";
    ctx.fill();
    ctx.closePath();
};

pongs = [new Pong("Bottom", false), new Pong("Right", true), new Pong("Left", false), new Pong("Top", false)];
pong = pongs[1]

for (c = 0; c < brickCol; c++){
    for (r = 0; r < brickRows; r++){
        bricks.push({
            x: (c * (brickW + brickPadding)) + brickOffsetLeft,
            y: (r * (brickH + brickPadding)) + brickOffsetTop,
            status: 1
        });
    }
}

function drawBall(){
    ctx.beginPath();
    ctx.arc(x, y, ballR, 0, Math.PI * 2);
    ctx.fillStyle = "#00C853";
    ctx.fill();
    ctx.closePath();
}

function drawPongs() {
    for(let i = 0; i < pongs.length; i++){
        pongs[i].drawPong();
    }
}

function drawBricks(){
    bricks.forEach(function(brick) {
        if (!brick.status) return;

        ctx.beginPath();
        ctx.rect(brick.x, brick.y, brickW, brickH);
        ctx.fillStyle = "#FE0101";
        ctx.fill();
        ctx.closePath();
    });
}

function collisionDetection(){
    bricks.forEach(function(b){
        if (!b.status) return;

        var inBricksColumn = x > b.x && x < b.x + brickW && (Math.abs(y - b.y) < ballR || Math.abs(y - (b.y + brickH) < ballR)),
            inBricksRow = y > b.y && y < b.y + brickH && (Math.abs(x - b.x) < ballR || Math.abs(x - (b.x + brickW) < ballR));
        
        if (inBricksColumn && inBricksRow){
            if (Math.abs(x - b.x) <= dx || Math.abs(x - (b.x + brickW)) <= dx){
                dx = -dx;
                b.status = 0;
            }
            else{
                dy = - dy;
                b.status = 0;
            }
        }
    })
}

function draw(){
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawBricks();
    drawBall();
    drawPongs();
    collisionDetection();

    if(gameOver()){

        document.location.reload();
    }

    var RIGHT_ARROW = 39, LEFT_ARROW = 37, UP_ARROW = 38, DOWN_ARROW = 40;


    for (let i = 0; i < pongs.length; i++){
        if(pongs[i].side == "Right"){
            if (y > pongs[i].y && y < pongs[i].y + pongW && x > pongs[i].x && x < pongs[i].x + pongH){
                var velocity = Math.sqrt(dy**2 + dx**2);
                var normalisedRelativeOffset = -(y - (pongs[i].pos + pongW/2)) / (pongW/2);
                var bounceAngle = normalisedRelativeOffset * 5 * Math.PI / 12;
                dy = velocity * Math.sin(bounceAngle);
                dx = -velocity * Math.cos(bounceAngle);
                console.log(dx);
            }
        }
        else if(pongs[i].side == "Left"){
            if (y > pongs[i].y && y < pongs[i].y + pongW && x > pongs[i].x && x < pongs[i].x + pongH){
                var velocity = Math.sqrt(dy**2 + dx**2);
                var normalisedRelativeOffset = -(y - (pongs[i].pos + pongW/2)) / (pongW/2);
                var bounceAngle = normalisedRelativeOffset * 5 * Math.PI / 12;
                dy = velocity * Math.sin(bounceAngle);
                dx = velocity * Math.cos(bounceAngle);
                console.log(dx);
            }
        }
        else if (pongs[i].side == "Bottom"){
            if (x > pongs[i].x && x < pongs[i].x + pongW && y < pongs[i].y && y > pongs[i].y - pongH){
                var velocity = Math.sqrt(dy**2 + dx**2);
                var normalisedRelativeOffset = (x - (pongs[i].pos + pongW/2)) / (pongW/2); // -1 to 1
                var bounceAngle = normalisedRelativeOffset * 5 * Math.PI / 12; 
                dy = -velocity * Math.cos(bounceAngle);
                dx = velocity * Math.sin(bounceAngle);
            }
        }
        else if (pongs[i].side == "Top"){
            if (x > pongs[i].x && x < pongs[i].x + pongW && y > pongs[i].y && y < pongs[i].y + pongH){
                var velocity = Math.sqrt(dy**2 + dx**2);
                var normalisedRelativeOffset = (x - (pongs[i].pos + pongW/2)) / (pongW/2);
                var bounceAngle = normalisedRelativeOffset * 5 * Math.PI / 12;
                dy = velocity * Math.cos(bounceAngle);
                dx = velocity * Math.sin(bounceAngle);
                console.log(normalisedRelativeOffset);
                console.log(dy);
            }
        }
    }

    // function ballOverPong() { return x > pong.pos && x < pong.pos + pongW; }
    function hitBottom() { return y + dy > canvas.height - ballR; }
    function gameOver() { return hitBottom() || hitSideWall() || hitTop();}
    function hitSideWall() { return x + dx > canvas.width - ballR || x + dx < ballR;}
    function hitTop() {return y + dy < ballR; }
    function xOutOfBounds () { return x + dx > canvas.width - ballR || x + dx < ballR;}
    function rightPressed(e) { return e.keyCode == RIGHT_ARROW; }
    function leftPressed(e) { return e.keyCode == LEFT_ARROW; }
    function upPressed(e) {return e.keyCode == UP_ARROW; }
    function downPressed(e) { return e.keyCode == DOWN_ARROW; }

    function keyDown(e){
        rightKey = rightPressed(e);
        leftKey = leftPressed(e);
        upKey = upPressed(e);
        downKey = downPressed(e);
    }
    function keyUp(e){
        rightKey = rightPressed(e) ? false: rightKey;
        leftKey = leftPressed(e) ? false: leftKey;
        upKey = upPressed(e) ? false: upKey;
        downKey = downPressed(e) ? false: downKey;
    }

    document.addEventListener("keydown", keyDown, false);
    document.addEventListener("keyup", keyUp, false);

    if(pong.side == "Top" || pong.side =="Bottom"){
        var maxDelta = canvas.width - pongW, minDelta = 0, pongDelta = rightKey ? 7 : leftKey ? -7 : 0;
    }
    else{
        var maxDelta = canvas.width - pongW, minDelta = 0, pongDelta = upKey ? -7 : downKey ? 7 : 0;
    }
    pong.pos = pong.pos + pongDelta;
    pong.pos = Math.min(pong.pos, maxDelta);
    pong.pos = Math.max(pong.pos, minDelta);

    x += dx;
    y += dy;
}

setInterval(draw, 10);
