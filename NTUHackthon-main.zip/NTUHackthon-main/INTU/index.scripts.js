window.onload = init 

state = {
    toggleState: "Create",
}

function init(){ 
    toggleInit()
}

function toggleInit(){
    let switchOptions = document.querySelectorAll(".switch-options")
    let create = switchOptions[0]
    let join = switchOptions[1]
    create.addEventListener("click", ()=> changeToggle("Create"))
    join.addEventListener("click", ()=> changeToggle("Join"))
}

function changeToggle(toggleState){ 
    if (state.toggleState === toggleState){
        return
    }
    state.toggleState = toggleState
    let switchOptions = document.querySelectorAll(".switch-options")
    let create = switchOptions[0]
    let join = switchOptions[1]
    let grow, shrink;
    if (toggleState == "Join"){
        grow = create
        shrink = join
    }else{
        grow = join
        shrink = create
    }
    grow.classList.remove("shrink")
    grow.classList.add("grow")
    shrink.classList.remove("grow")
    shrink.classList.add("shrink")
    let createInputs = document.querySelectorAll(".create-input")
    let joinInputs = document.querySelectorAll(".join-input")
    for (i of createInputs){
        if (toggleState === "Create"){
            i.classList.remove('hidden')
        }else{
            i.classList.add('hidden')
        }
    }
    for (i of joinInputs){
        if (toggleState === "Join"){
            i.classList.remove('hidden')
        }else{
            i.classList.add('hidden')
        }
    }
    let bg = document.querySelector(".landing-screen-bg")
    console.log(bg)
    if (toggleState === "Create"){
        console.log(bg.style.backgroundImage)
        bg.style.backgroundImage = "linear-gradient(rgb(26, 255, 0),#3e98b6,hsl(287, 42%, 19%));"
    }else{
        bg.style.backgroundImage = "linear-gradient(rgb(255, 238, 0),#203a43,hsl(286, 81%, 45%));"
    }
    

}